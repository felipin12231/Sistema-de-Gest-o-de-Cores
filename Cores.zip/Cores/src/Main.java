public class Main {
    public static void main(String[] args) {
        FormaManager formaManager = new FormaManager();

        try {
           //validas
            formaManager.addForma("Vermelho", "0,0", 10);
            formaManager.addForma("Verde", "1,1", 20);
            formaManager.addForma("Vermelho", "2,2", 15); // Reutilizando a cor "Vermelho"
            formaManager.addForma("Azul", "3,3", 25);
            formaManager.addForma("Verde", "4,4", 30); // Reutilizando a cor "Verde"

           //invalidas
            formaManager.addForma("", "5,5", 12); // Cor vazia
            formaManager.addForma("Amarelo", "6,6", -5); // Tamanho negativo

        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }


        formaManager.apresentar();
    }
}
