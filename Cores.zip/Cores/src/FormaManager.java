import java.util.ArrayList;
import java.util.List;

public class FormaManager {
    private List<Forma> formas;
    private CorFactory corFactory;

    public FormaManager() {
        formas = new ArrayList<>();
        corFactory = new CorFactory();
    }

    public void addForma(String nomeCor, String posicao, int tamanho) {
        if (nomeCor == null || nomeCor.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome da cor não pode ser vazio.");
        }
        if (tamanho < 0) {
            throw new IllegalArgumentException("O tamanho não pode ser negativo.");
        }
        Cor cor = corFactory.getCor(nomeCor);
        formas.add(new Forma(cor, posicao, tamanho));
    }

    public void apresentar() {
        for (Forma forma : formas) {
            System.out.println(forma);
        }
    }
}
